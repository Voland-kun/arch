package LSP;

public abstract class QuadRangle {
    public abstract int area();
}
