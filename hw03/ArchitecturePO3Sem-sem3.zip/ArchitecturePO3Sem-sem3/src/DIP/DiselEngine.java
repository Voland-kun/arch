package DIP;

public class DiselEngine implements Engine{
    @Override
    public void start() {
        System.out.println("Завели дизельный двигатель");
    }
}
