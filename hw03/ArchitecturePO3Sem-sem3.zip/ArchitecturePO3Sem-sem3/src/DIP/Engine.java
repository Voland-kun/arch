package DIP;

public interface Engine {
    void start();
}
