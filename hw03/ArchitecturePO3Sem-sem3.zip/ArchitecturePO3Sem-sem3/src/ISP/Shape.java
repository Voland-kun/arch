package ISP;

public interface Shape {
    double perimetr();
}
