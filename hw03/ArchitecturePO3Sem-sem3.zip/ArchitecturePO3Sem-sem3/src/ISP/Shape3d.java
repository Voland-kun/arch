package ISP;

public interface Shape3d extends Shape{
    double value();
}
